import asyncio
import logging

import uvicorn
from fastapi import FastAPI

from app.api.main import api_router

app = FastAPI(
    debug=True, title="smart_halva",
    docs_url="/", version="0.0.1"
)

app.include_router(api_router, prefix="/api")


async def main():
    config = uvicorn.Config(
        app="main:app",
        host="0.0.0.0",
        port=8000,
    )
    server = uvicorn.Server(config)
    logging.info("start uvicorn server")
    await server.serve()


if __name__ == "__main__":
    asyncio.run(main(), debug=True)
