from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, File, UploadFile, status
from fastapi.exceptions import HTTPException

from app.categories import Categories
from app.core import logic
from app.core.pydantic_models import PartnerReturn, StatisticsReturn
from app.core.storage import upload_to_bucket

api_router = APIRouter()


@api_router.get("/info")
async def index() -> str:
    return "hello world"


@api_router.post("/upload_file")
async def upload_file(
    user_id: int,
    file: Annotated[UploadFile, File()]
) -> None:
    print(file.content_type)
    await upload_to_bucket(user_id, file)
    # потом вот здесь нужно воткнуть запрос в нейронку
    raise Exception()


@api_router.get("/user_info/{user_id}")
async def get_user_info(user_id: int) -> StatisticsReturn:
    """ то же самое что и get_user_info_bound, но без ограничения времени"""
    ret = logic.get_statistics(user_id)
    return ret


@api_router.get("/user_info_bound/{user_id}")
async def get_user_info_bound(
    user_id: int,
    time_start: datetime, time_end: datetime,
) -> StatisticsReturn:
    ret = logic.get_statistics_bound(user_id, time_start, time_end)
    return ret


@api_router.get("/get_all_partners")
async def get_all_partners() -> list[PartnerReturn]:
    return logic.fetch_all_partners()


@api_router.post("/add_partner")
async def add_partner(partner_name: str, prime_category: str) -> None:
    if prime_category not in Categories:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            "unrecognized category"
        )

    logic.insert_partner(partner_name, prime_category)
