import enum


class Categories(enum.StrEnum):
    PRODUCTS = "products"
    CLOSE = "close"
    CAFE = "cafe"
    MEDICINE = "medicine"
    BEAUTY = "beauty"
    SPORT = "sport"
    ELECNTRONICS = "electronics"
    VEHICLE = "vehicle"
    UNRECOGNIZED = "unrecognized"
