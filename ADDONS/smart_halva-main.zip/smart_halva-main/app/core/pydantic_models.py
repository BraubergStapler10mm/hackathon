from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel


class PartnerReturn(BaseModel):
    name: str
    prime_category: str


@dataclass
class CategoryAmount:
    category: str
    amount: Decimal


class StatisticsReturn(BaseModel):
    user_id: int
    statisitcs: list[CategoryAmount]
