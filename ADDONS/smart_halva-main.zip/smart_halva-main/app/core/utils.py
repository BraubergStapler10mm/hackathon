from typing import Generator

from sqlalchemy import Engine, create_engine
from sqlalchemy.orm import Session

from app.settings import settings

_engine = None
_sqlalchemy_url = "postgresql+psycopg://postgres:hackme@db:5432/postgres"


def get_db_enginge() -> Engine:
    global _engine
    if _engine is None:
        _engine = create_engine(_sqlalchemy_url, echo=True)
    return _engine
