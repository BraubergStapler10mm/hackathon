import random

import minio
from fastapi import UploadFile, status
from fastapi.exceptions import HTTPException
from minio.error import S3Error

from app.settings import settings


def get_storage_clinet() -> minio.Minio:
    return minio.Minio(
        endpoint="minio:9000",
        access_key=settings.MINIO_ROOT_USER,
        secret_key=settings.MINIO_ROOT_PASSWORD,
        cert_check=False, secure=False,
    )


async def upload_to_bucket(bucket_name: int, file: UploadFile) -> None:
    storage = get_storage_clinet()
    length = file.size
    if length is None:
        length = -1
    fname = file.filename
    if fname is None:
        fname = str(random.randbytes(10))

    if not storage.bucket_exists(str(bucket_name)):
        storage.make_bucket(str(bucket_name))
    try:
        res = storage.put_object(
            str(bucket_name), fname, file.file, length=length
        )
        print(f"File {fname} uploaded")
        print(res)
    except S3Error as e:
        print(f"Error while uploading file {e}")
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE)
