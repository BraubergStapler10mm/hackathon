from datetime import datetime

from sqlalchemy import DECIMAL, String, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


class UserItemPurchase(Base):
    __tablename__ = "user_item_purchase"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column()
    time_add: Mapped[datetime] = mapped_column(insert_default=func.now())
    category: Mapped[str] = mapped_column(String(50))
    total: Mapped[DECIMAL] = mapped_column(DECIMAL(2, 5))


class Partner(Base):
    __tablename__ = "partner"
    name: Mapped[str] = mapped_column(String(100), primary_key=True)
    prime_category: Mapped[str] = mapped_column(String(50))
