from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.orm import sessionmaker

from app.core.models import Partner, UserItemPurchase
from app.core.pydantic_models import (CategoryAmount, PartnerReturn,
                                      StatisticsReturn)
from app.core.utils import get_db_enginge


def fetch_all_partners() -> list[PartnerReturn]:
    engine = get_db_enginge()
    _session = sessionmaker(engine)
    ret = []
    with _session.begin() as session:
        query = select(Partner)
        for partner in session.scalars(query):
            ret.append(PartnerReturn(
                name=partner.name,
                prime_category=partner.prime_category
            ))
    return ret


def insert_partner(name: str, category: str):
    engine = get_db_enginge()
    _session = sessionmaker(engine)
    with _session.begin() as session:
        new = Partner(name=name, prime_category=category)
        session.add(new)
        session.commit()


def get_statistics_bound(
    user_id: int,
    lower_bound: datetime,
    upper_bound: datetime,
) -> StatisticsReturn:
    engine = get_db_enginge()
    _session = sessionmaker(engine)
    ret = StatisticsReturn({"user_id": user_id, "statisitcs": []})
    with _session.begin() as session:
        query = select(
            UserItemPurchase.category,
            func.sum(UserItemPurchase.total).label("total_sum")
        ).filter(UserItemPurchase.id == user_id).filter(
            UserItemPurchase.time_add >= lower_bound
            and UserItemPurchase <= upper_bound
        ).group_by(
            UserItemPurchase.category
        )
        res = session.execute(query)
        for stat in res.all():
            q_user_id, q_category, q_sum = stat
            category_amount = CategoryAmount(q_category, q_sum)
            ret.statisitcs.append(category_amount)

    return ret


def get_statistics(user_id: int) -> StatisticsReturn:
    engine = get_db_enginge()
    _session = sessionmaker(engine)
    ret = StatisticsReturn(user_id=user_id, statisitcs=[])
    with _session.begin() as session:
        query = select(
            UserItemPurchase.category,
            func.sum(UserItemPurchase.total).label("total_sum")
        ).filter(UserItemPurchase.id == user_id).group_by(
            UserItemPurchase.category
        )
        res = session.execute(query)
        for stat in res.all():
            q_user_id, q_category, q_sum = stat
            category_amount = CategoryAmount(q_category, q_sum)
            ret.statisitcs.append(category_amount)

    return ret
